## Module <hr_contract_types>

#### 03.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit

